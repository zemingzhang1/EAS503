def ex1():
    """Return the boolean True"""


def ex2():
    """Return the boolean False"""


def ex3():
    """Return integer 10"""


def ex4():
    """Return float 3.5"""


def ex5():
    """Return the string a"""


def ex6():
    """Return the string EAS503"""


def ex7():
    """
    True or False: Buffalo is in New York.
    Return True or False
    """


def ex8():
    """
    True or False: New York is the largest state in the United States
    Return True or False
    """


def ex9():
    """
    Which of the following in an incorrect Python variable name? Return a letter without parenthesis.
    (a) -- test1234
    (b) -- 3pi
    (c) -- __factor
    (d) -- mean__value__2
    """


def ex10():
    """
    Square 3 and 4 and return the their summed value
    """


def ex11():
    """
    Divide 2020 by 5 and return the value
    """


def ex12():
    """
    Return the remainder of 512 divided by 16
    """


def ex13():
    """
    Return 36 divided by 5
    """


def ex14():
    """
    Return the quotient when 36 divided by 5
    """


def ex15():
    """
    Return the area of a circle with radius 6
    """


def ex16():
    """
    Given the temperature in fahrenheit (temperature_in_f), return the temperature in Celsius
    """


def ex17():
    """
    Given the string 'EAS503', return the letter E using the square-bracket syntax
    """


def ex18():
    """
    Given the string 'EAS503', return the letter S using the square-bracket syntax
    """


def ex19():
    """
    Given the string 'EAS503', return the last character in the string using the square-bracket syntax
    """


def ex20():
    """
    Given a float value, convert it to an int type and return the value
    """


def ex21():
    """
    PI is given in string data type, return it in float data type
    """


def ex22():
    """
    Return the data type of the variable test_variable
    """


def ex23():
    """
    Return the data type of the variable test_variable
    """


def ex24():
    """
    True or False: In Python you can declare a variable without specifying its data type.
    Return True or False
    """


def ex25():
    """
    True or False: In Python a variable that was used as a string can be reused as a float.
    Return True or False
    """


def ex26():
    """
    Given the height and base of a triangle, calculate its area and return it

    """


def ex27(filename):
    """
    Open the file specified by filename and sum the values found in them. 
    Return the value of sum and write the string 'The total is <>.' in a file called 'ex1_output.txt' 
    Must name output file: 'ex1_output.txt'
    """
